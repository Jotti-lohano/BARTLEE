<?php

namespace App\Http\Controllers\Admin\Smiles;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SmileController extends Controller
{
    //
}
