<?php

namespace App\Http\Controllers\Api\Artist;

use App\Models\Profession;
use App\Models\UserArtist;
use App\Models\UserProfile;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Exception;

class ArtistController extends Controller
{
    //
    public function getProfessions(){
       try {
            $professions = Profession::select('id','Profession')->get();
                return api_success('Professions',$professions );
            }
        catch (\Exception $ex) {
            return api_error('message: ' . $ex->getMessage(), 500 ) ;
        }
    }

     public function getWorks(Request $request)
    {
        # code...
 
        if (auth('api')->check()) {

            $user = UserProfile::where('user_id',Auth()->user()->id)->first();
           
          
            if ($user) {

                $artist = UserArtist::with('artist_work:id,user_artist_id,content')->where('user_profile_id',$user->id)->get();
                
                return api_success("Get Your Works", $artist);
                
            }else{
                return api_error('No Record Found');
            }
      
           
        }else{
            return api_error('PLease login first');
        }
    }

    public function uploadContent(Request $request)
    {
        # code...


        try{

            $user = UserProfile::where('user_id',auth()->user()->id)->first();
            $userArtist = UserArtist::where("user_profile_id",$user->id)->first();

            if($request->hasfile('upload_content')){

                foreach($request->file('upload_content') as $file){
                    $name = time().$file->getClientOriginalName();
                   
                    $file->move(public_path('artist_content'),$name);
                    $contentName = 'artist_content/'.$name;
                    $userArtist->artist_work()->create([
                        'content' =>$contentName,
                    
                    ]);
                }
                return api_success1('Content Added successfully' );
            }
            
        }catch(\Exception $ex){

            return api_error('message: ' . $ex->getMessage(), 500 ) ;
        }
    }
}
