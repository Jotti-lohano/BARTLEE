<?php


namespace App\Services\Common;

use Hash;
use App\Models\User;
use HelperConstants;
use App\Traits\UploadAble;
use Illuminate\Support\Str;
use App\Models\PasswordReset;
use Illuminate\Validation\ValidationException;
use App\Notifications\{SignupActivation, PasswordResetRequest};


class UserService
{

    use UploadAble;

    protected $model;

    public function __construct() {
        $this->model = new User;
    }

    public function create(object $request)
    {

        $collection = collect($request->all());

        $name = $collection->get('name', '');
        $email = $collection->get('email', '');
        $password = Hash::make($collection->get('password', ''));


        $phone = $collection->get('phone', '');        
        $dialing_code = $collection->get('dialing_code', '');
        $country = $collection->get('country', '');

        if ($collection->get('status')) {
            $status = $collection->get('status', User::ACTIVE_STATUS);
            $verified = 1;
        } else {
            $status = $collection->get('status', User::PENDING_STATUS);
            $verified = 1;
        }

        $dob = $collection->get('dob', null);
        
        $photo = '';

        if ($request->has('photo')) {
            $saveFile = saveFile($request->photo, HelperConstants::PROFILE_PHOTO_DIRECTORY,  HelperConstants::UPLOAD_DISK);
            $photo = $saveFile['fileName'];
        }

        $collection = collect();
        $volunteer = $collection->merge(
            compact('name', 'email', 'password', 'status', 'dob', 'dialing_code', 'phone', 'country', 'photo', 'verified')
        )->toArray();


        // Create Volunteer Here
        $user = $this->model->create($volunteer);

        return $user;
    }

    public function update($request)
    {
        auth()->user()->name = $request->name;
        auth()->user()->dialing_code = $request->dialing_code;
        auth()->user()->phone = $request->phone;
        auth()->user()->dob = $request->dob;
        auth()->user()->country = $request->country;

        if ($request->has('photo')) {
            $saveFile = saveFile($request->photo, HelperConstants::PROFILE_PHOTO_DIRECTORY,  HelperConstants::UPLOAD_DISK);
            auth()->user()->photo = $saveFile['fileName'];
        }

        auth()->user()->save();

        return auth()->user();
    }

    public function getAll()
    {
        return $this->model->all();
    }

    public function show($id)
    {
        return $this->model->find($id);
    }

    public function updatePassword($request, $id)
    {
        $user = $this->model->find($id);

        if ($request->has('password')) {
            $user->password = Hash::make($request->password);
        }
        $user->save();

        return $user;
    }

    public function updateStatus($request, $id)
    {
        $user = $this->model->find($id);
        $user->status = $request->status;
        $user->save();

        return $user;
    }

    public function destroy($id)
    {
        $this->model->find($id)->delete();
        return response()->json(['status' => true, 'message' => 'deleted successfully']);
    }

    public function getUserByEmail($email)
    {
        return $this->model->where('email', $email)->first();
    }

    public function getUserByPhone($phone)
    {
        return $this->model->where('phone', $phone)->first();
    }

    public function checkLogin($request, $type='user')
    {

        if ($request->exists('phone') && $request->filled('phone')) {
            $user = $this->getUserByPhone($request->phone);

            if (!$user || !Hash::check($request->password, $user->password)) {
                throw ValidationException::withMessages([
                    'phone' => ['The provided credentials are incorrect.'],
                ]);
            }
        } else {
            $user = $this->getUserByEmail($request->email);

            if (!$user || !Hash::check($request->password, $user->password)) {
                throw ValidationException::withMessages([
                    'email' => ['The provided credentials are incorrect.'],
                ]);
            }
        }

        if ($user->status == 2) {
            throw ValidationException::withMessages([
                'unverified' => ['Your Account has been disabled by the Admin'],
            ]);
        }


        if (strtolower($user->type) != strtolower($type)) {
            throw ValidationException::withMessages([
                'error' => ['Invalid Account Type, Only admin users can login'],
            ]);
        }

        if ($user->verified == 0) {
            return ['token' => $user->createToken('123', ['account:unverified'])->plainTextToken, 'user' => $user];
        }



        $user->photo = $user->photo ? asset(HelperConstants::LOGO_DIRECTORY . $user->photo) : '';
        return ['token' => $user->createToken('123', ['account:verified'])->plainTextToken, 'user' => $user, 'location' => $user->location];
    }

    public function updateDeviceToken($email, $deviceToken)
    {
        $user = $this->getUserByEmail($email);
        $user->device_token = $deviceToken;
        $user->save();
    }

    public function updateDeviceTokenByPhone($phone, $deviceToken)
    {
        $user = $this->getUserByPhone($phone);
        $user->device_token = $deviceToken;
        $user->save();
    }

    public function reset($request)
    {
        $user = $this->getUserByEmail($request->email);

        if (!$user) {
            throw ValidationException::withMessages([
                'email' => ['Email is not registered'],
            ]);
        }

        $passwordReset = $this->generateToken($user->email);

        if ($user && $passwordReset)
            $user->notify(
                new PasswordResetRequest($user, $passwordReset->token)
            );

        return response()->json([
            'status' => true,
            'msg' => 'We have sent you a verification code!'
        ]);
    }

    public function verifyAndUpdatePassword($request)
    {

        // $code = $this->getToken($request);

        // $user = $this->getUserByEmail($code->email);
        $user = $this->getUserByEmail($request->email);

        $this->updatePassword($request, $user->id);

        // $this->deleteToken($code->token);

        return response()->json(['status' => true, 'msg' => 'Password changed successfully']);
    }

    public function sendAccountVerification($user)
    {
        $verification = $this->generateToken($user->email);

        if ($user && $verification)
            $user->notify(
                new SignupActivation($user, $verification->token)
            );

        return response()->json([
            'status' => true,
            'msg' => 'We have sent you a verification code!'
        ]);
    }

    public function generateToken($email)
    {
        return PasswordReset::updateOrCreate(
            ['email' => $email],
            [
                'email' => $email,
                'token' => strtolower(rand(1000,9999)),
                'created_at' => now()
            ]
        );
    }

    public function markVerify($request, $email)
    {
        $code = $this->getToken($request);

        if (!$code || $code->email != $email) {
            return false;
        }
        $user = $this->getUserByEmail($email);

        $user->verified = 1;

        // Remove after development of admin
        $user->status = 1;

        $user->save();

        $this->deleteToken($request->token);

        return true;
    }

    public function getToken($request)
    {
        return PasswordReset::where('token', $request->token)->first();
    }

    public function deleteToken($token)
    {
        PasswordReset::where('token', $token)->delete();
    }

    public function setLocation($request, $userId)
    {
        $user = $this->model->where('id', $userId)->first();

        if ($user->location) {

            $location['latitude'] = $request->latitude;
            $location['longitude'] = $request->longitude;
            $location['text'] = $request->location;
            $user->location()->update($location);
        } else {

            $location = new \App\Models\Location;
            $location->latitude = $request->latitude;
            $location->longitude = $request->longitude;
            $location->text = $request->location;
            $user->location()->save($location);
        }

        return $user;
    }

    public function pushNotificationStatus($userId, $status)
    {
        $user = $this->model->find($userId);
        $user->push_notification = $status;
        $user->save();

        return $user;
    }

    public function eventRatingStatus($userId, $status)
    {
        $user = $this->model->find($userId);
        $user->event_rating = $status;
        $user->save();

        return $user;
    }

    public function logout($request)
    {
        return $request->user()->currentAccessToken()->delete();
    }

    public function listing($request, $pagination)
    {
        return $this->model
            // ->where(function($q) {
            //     $q->where('status', '!=', $this->model::PENDING_STATUS)->orWhere('status', '!=', $this->model::REJECT_STATUS);
            // })
            ->whereNotIn('status', [$this->model::PENDING_STATUS, $this->model::REJECT_STATUS])
            ->when(request()->filled('status'), function ($q) {
                $q->whereStatus(request('status'));
            })
            ->when(request()->filled('search'), function ($q) {
                $q->where('name', 'like', '%' . request("search") . '%');
            })
            ->when(request()->filled('start'), function ($q) {
                $q->whereDate('created_at', '>=', request('start'))->whereDate('created_at', '<=', request('end'));
            })
            ->orderBy('id', 'DESC')
            ->paginate($pagination);
    }

    public function requestListing($request, $pagination)
    {
        return $this->model
            ->where(function ($q) {
                $q->where('status', $this->model::PENDING_STATUS)->orWhere('status', $this->model::REJECT_STATUS);
            })
            ->when(request()->filled('status'), function ($q) {
                $q->whereStatus(request('status'));
            })
            ->when(request()->filled('search'), function ($q) {
                $q->where('name', 'like', '%' . request("search") . '%');
            })
            ->when(request()->filled('start'), function ($q) {
                $q->whereDate('created_at', '>=', request('start'))->whereDate('created_at', '<=', request('end'));
            })
            ->orderBy('id', 'DESC')
            ->paginate($pagination);
    }

    public function accountStatus($userId, $status)
    {
        $user = $this->model->find($userId);
        $user->status = $status;
        $user->save();

        return $user;
    }
}
